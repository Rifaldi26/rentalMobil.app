<?php
// ─────────────────────────────────────────────────────────────────────────────
// TAMBAHKAN baris ini ke web.php
// ─────────────────────────────────────────────────────────────────────────────

// Di bagian atas, tambahkan use:
use App\Http\Controllers\NotifikasiController;

// ── Di dalam Route::middleware(['auth', 'verified'])->group() (area User) ──
Route::get('/notifikasi',              [NotifikasiController::class, 'userIndex'])->name('user.notifikasi');
Route::get('/notifikasi/unread',       [NotifikasiController::class, 'unread'])->name('notifikasi.unread');
Route::post('/notifikasi/{notifikasi}/baca', [NotifikasiController::class, 'baca'])->name('notifikasi.baca');
Route::delete('/notifikasi/hapus-semua',    [NotifikasiController::class, 'hapusSemua'])->name('notifikasi.hapus');

// ── Di dalam Route::middleware admin (prefix 'admin') ──
Route::get('/notifikasi', [NotifikasiController::class, 'adminIndex'])->name('notifikasi');
